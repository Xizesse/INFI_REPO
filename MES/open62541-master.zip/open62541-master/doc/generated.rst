.. _generated-definitions:

Generated Definitions
=====================

The following definitions are auto-generated from XML files that are part of the
OPC UA standard.

Generated Data Types
--------------------

.. include:: types_generated.rst

.. include:: statuscodes.rst
